<?php

namespace App\Models\Students\Traits\Relationship;

trait Relationship
{
}

<?php namespace App\Models\Permission\Traits\Relationship;

trait Relationship
{
}
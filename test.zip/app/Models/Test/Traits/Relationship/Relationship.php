<?php namespace App\Models\Test\Traits\Relationship;

trait Relationship
{
}
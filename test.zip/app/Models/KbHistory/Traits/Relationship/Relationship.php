<?php

namespace App\Models\KbHistory\Traits\Relationship;

trait Relationship
{
}

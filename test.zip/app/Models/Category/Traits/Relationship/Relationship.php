<?php namespace App\Models\Category\Traits\Relationship;

trait Relationship
{
}
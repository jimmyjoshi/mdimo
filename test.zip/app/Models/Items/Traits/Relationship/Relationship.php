<?php namespace App\Models\Items\Traits\Relationship;

trait Relationship
{
}
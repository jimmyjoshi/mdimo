<?php

namespace App\Models\Sample\Traits\Relationship;

trait Relationship
{
}

<div class="toolbar-toggle">
    <a id="filter-toggle-switch" class="pointer fa fa-filter"></a>
    <a id="action-toggle-switch" class="pointer fa fa-cog"></a>
</div>
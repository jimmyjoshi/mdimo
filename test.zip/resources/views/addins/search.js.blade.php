<script type="text/javascript">
    jQuery("select.searchBy").select2({
        minimumResultsForSearch: Infinity
    });
</script>